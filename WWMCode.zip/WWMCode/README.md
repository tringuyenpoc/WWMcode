# WWM Code – tự nhập code Where Winds Meet (Android)

App dùng **Trợ năng (Accessibility)** để lặp lại thao tác: chạm ô nhập → điền code → bấm xác nhận → chạm đóng popup "Nhận được" → sang code tiếp theo.

## Build APK (GitHub Actions)
1. Tạo repo mới trên GitHub, upload toàn bộ thư mục này (giữ nguyên `.github/workflows/build.yml`).
2. Tab **Actions** → workflow **Build APK** tự chạy (hoặc bấm *Run workflow*).
3. Xong (~3–5 phút) → mở lần chạy → tải artifact **WWMCode-apk** → giải nén ra `app-debug.apk` → cài lên điện thoại.

## Cài đặt lần đầu
1. Mở app → **① Bật quyền Trợ năng** → chọn *WWM Code* → bật.
   - Android 13+ nếu bị mờ/không cho bật: Cài đặt → Ứng dụng → WWM Code → ⋮ → **Cho phép cài đặt hạn chế**, rồi bật lại.
   - Máy vivo/Xiaomi: nên tắt tối ưu pin cho app để dịch vụ không bị tắt.
2. Dán danh sách code (dán cả nội dung trang web cũng được) → **Lọc & lưu**.
   Hoặc trên trình duyệt chọn văn bản → Chia sẻ → WWM Code.
3. **④ Hiện bảng điều khiển nổi** → mở game → Cài đặt → Khác → Mã đổi quà.
4. Trên bảng nổi bấm **📍**, chạm lần lượt:
   1. Ô nhập code
   2. Nút xác nhận (mũi tên)
   3. Vùng trống **bên trong** khung nhập code (để đóng popup phần thưởng mà không đóng khung nhập)
5. Bấm **1** để thử 1 code. Ổn thì bấm **▶** để chạy hết.

Dừng: **■** hoặc nút **giảm âm lượng**. Kéo bảng nổi bằng phần chữ bên trái.

## Nếu không chạy đúng
| Hiện tượng | Cách xử lý |
|---|---|
| "Không tìm thấy ô nhập chữ" | Tăng *Chờ sau khi chạm ô nhập* (1200–1500). Nếu vẫn lỗi: game không dùng ô nhập chuẩn của Android → cách điền tự động này không áp dụng được. |
| Code điền vào nhưng không gửi | Thử bỏ tick *Đóng bàn phím sau khi điền*, hoặc cài lại điểm 2. |
| Popup chưa đóng đã sang code sau | Tăng *Chờ kết quả* (3000–4000) hoặc *Số lần chạm đóng popup* = 2. |
| Khung nhập code bị đóng mất | Điểm 3 đang nằm ngoài khung → cài lại 📍, chạm vào vùng trống bên trong khung. |

## Giới hạn
- App **không đọc được** game báo code đúng/sai/hết hạn (game tự vẽ giao diện). Code nào đã gửi thì đánh dấu "đã nhập".
- Vị trí chạm gắn với hướng màn hình: cài 📍 khi game đang ngang.
- Quà về **Hộp thư** trong game, cần vào nhận.
