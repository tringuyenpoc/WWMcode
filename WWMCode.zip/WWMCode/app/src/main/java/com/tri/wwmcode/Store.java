package com.tri.wwmcode;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.PointF;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lưu danh sách code, code đã nhập, vị trí chạm và thời gian chờ. */
public final class Store {
    private static final String PREF = "wwm";
    private final SharedPreferences sp;

    public Store(Context c) {
        sp = c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    // ---------- Code ----------
    public String codesText() { return sp.getString("codes", ""); }

    public void saveCodes(List<String> codes) {
        sp.edit().putString("codes", String.join("\n", codes)).apply();
    }

    public List<String> codes() {
        List<String> out = new ArrayList<>();
        for (String s : codesText().split("\n")) {
            s = s.trim();
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    public Set<String> done() { return new HashSet<>(sp.getStringSet("done", new HashSet<>())); }

    public void markDone(String code) {
        Set<String> d = done();
        d.add(code);
        sp.edit().putStringSet("done", d).apply();
    }

    public void clearDone() { sp.edit().remove("done").apply(); }

    public List<String> pending() {
        Set<String> d = done();
        List<String> out = new ArrayList<>();
        for (String c : codes()) if (!d.contains(c)) out.add(c);
        return out;
    }

    /**
     * Lọc code từ văn bản dán vào (có thể lẫn chữ của trang web).
     * Giữ chuỗi chữ+số dài 6–20 ký tự, có ít nhất 1 chữ số hoặc ≥3 chữ in hoa.
     */
    public static List<String> extractCodes(String text) {
        Set<String> out = new LinkedHashSet<>();
        Matcher m = Pattern.compile("(?<![A-Za-z0-9])[A-Za-z0-9]{6,20}(?![A-Za-z0-9])").matcher(text);
        while (m.find()) {
            String t = m.group();
            int digits = 0, upper = 0;
            for (char ch : t.toCharArray()) {
                if (Character.isDigit(ch)) digits++;
                else if (Character.isUpperCase(ch)) upper++;
            }
            if (digits == t.length()) continue; // chỉ toàn số -> bỏ
            if (digits > 0 || upper >= 3) out.add(t);
        }
        return new ArrayList<>(out);
    }

    // ---------- Vị trí chạm (0 = ô nhập, 1 = nút xác nhận, 2 = chỗ đóng popup) ----------
    public boolean calibrated() { return sp.getBoolean("calibrated", false); }

    public PointF point(int i) {
        return new PointF(sp.getFloat("px" + i, 0f), sp.getFloat("py" + i, 0f));
    }

    public void savePoints(PointF[] p) {
        SharedPreferences.Editor e = sp.edit();
        for (int i = 0; i < p.length; i++) {
            e.putFloat("px" + i, p[i].x).putFloat("py" + i, p[i].y);
        }
        e.putBoolean("calibrated", true).apply();
    }

    // ---------- Thời gian chờ ----------
    public int tapDelay() { return sp.getInt("tapDelay", 800); }       // sau khi chạm ô nhập
    public int resultDelay() { return sp.getInt("resultDelay", 2500); } // sau khi bấm xác nhận
    public int closeDelay() { return sp.getInt("closeDelay", 1000); }   // sau khi đóng popup
    public int closeTaps() { return sp.getInt("closeTaps", 1); }
    public boolean imeEnter() { return sp.getBoolean("imeEnter", true); }

    public void saveTiming(int tap, int result, int close, int taps, boolean ime) {
        sp.edit().putInt("tapDelay", tap).putInt("resultDelay", result)
                .putInt("closeDelay", close).putInt("closeTaps", taps)
                .putBoolean("imeEnter", ime).apply();
    }
}
