package com.tri.wwmcode;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private Store store;
    private TextView status;
    private EditText codesBox, tapDelay, resultDelay, closeDelay, closeTaps;
    private CheckBox imeEnter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        buildUi();
        handleShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleShare(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveTiming();
    }

    private void handleShare(Intent i) {
        if (i != null && Intent.ACTION_SEND.equals(i.getAction())) {
            CharSequence t = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (t != null) importText(t.toString());
        }
    }

    // ---------------- UI ----------------
    private void buildUi() {
        int pad = dp(14);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("WWM Code – tự nhập code");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        root.addView(button("① Bật quyền Trợ năng cho WWM Code", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        root.addView(label("② Danh sách code (mỗi dòng 1 code – có thể dán cả trang web, app tự lọc):"));
        codesBox = new EditText(this);
        codesBox.setMinLines(6);
        codesBox.setMaxLines(12);
        codesBox.setGravity(Gravity.TOP);
        codesBox.setTypeface(Typeface.MONOSPACE);
        codesBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        codesBox.setText(store.codesText());
        root.addView(codesBox);

        LinearLayout row = new LinearLayout(this);
        row.addView(button("Dán clipboard", v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            ClipData clip = cm.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                CharSequence t = clip.getItemAt(0).coerceToText(this);
                importText(codesBox.getText() + "\n" + t);
            } else toast("Clipboard trống");
        }), weight());
        row.addView(button("Lọc & lưu", v -> importText(codesBox.getText().toString())), weight());
        root.addView(row);

        root.addView(button("Xoá đánh dấu 'đã nhập' (nhập lại từ đầu)", v -> {
            store.clearDone();
            refresh();
            toast("Đã xoá đánh dấu");
        }));

        root.addView(label("③ Thời gian chờ (ms) – máy chậm thì tăng lên:"));
        tapDelay = number("Chờ sau khi chạm ô nhập", store.tapDelay(), root);
        resultDelay = number("Chờ kết quả sau khi bấm xác nhận", store.resultDelay(), root);
        closeDelay = number("Chờ sau khi đóng popup", store.closeDelay(), root);
        closeTaps = number("Số lần chạm để đóng popup", store.closeTaps(), root);
        imeEnter = new CheckBox(this);
        imeEnter.setText("Đóng bàn phím sau khi điền (Enter, nếu không được thì nút Back)");
        imeEnter.setChecked(store.imeEnter());
        root.addView(imeEnter);

        root.addView(button("④ Hiện bảng điều khiển nổi rồi mở game", v -> {
            saveTiming();
            CodeService s = CodeService.instance;
            if (s == null) {
                toast("Chưa bật quyền Trợ năng (bước ①)");
                return;
            }
            s.showPanel();
            toast("Mở game → Cài đặt → Khác → Mã đổi quà, rồi bấm 📍 trên bảng nổi");
            moveTaskToBack(true);
        }));

        TextView help = new TextView(this);
        help.setPadding(0, dp(12), 0, 0);
        help.setText("Cách dùng:\n"
                + "• Trong game mở khung nhập code (Cài đặt → Khác → Mã đổi quà).\n"
                + "• Bảng nổi: 📍 cài vị trí (chạm lần lượt: ô nhập → nút xác nhận → vùng trống BÊN TRONG khung nhập code để đóng popup).\n"
                + "• Bấm '1' để thử 1 code trước. Ổn thì bấm ▶ chạy hết.\n"
                + "• Dừng: bấm ■ hoặc nhấn nút GIẢM ÂM LƯỢNG.\n"
                + "• Kéo bảng nổi ra chỗ không che 3 điểm chạm.\n"
                + "• App không đọc được game báo code đúng/sai – code nào đã gửi sẽ được đánh dấu 'đã nhập'.");
        root.addView(help);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private void importText(String text) {
        List<String> codes = Store.extractCodes(text);
        store.saveCodes(codes);
        codesBox.setText(String.join("\n", codes));
        refresh();
        toast("Lọc được " + codes.size() + " code");
    }

    private void saveTiming() {
        if (tapDelay == null) return;
        store.saveTiming(num(tapDelay, 800), num(resultDelay, 2500), num(closeDelay, 1000),
                Math.max(1, num(closeTaps, 1)), imeEnter.isChecked());
    }

    private void refresh() {
        boolean on = CodeService.instance != null;
        int total = store.codes().size();
        int left = store.pending().size();
        status.setText("Trợ năng: " + (on ? "ĐÃ BẬT ✓" : "CHƯA BẬT ✗")
                + "\nVị trí chạm: " + (store.calibrated() ? "đã cài ✓" : "chưa cài")
                + "\nCode: " + total + " • đã nhập " + (total - left) + " • còn " + left);
    }

    // ---------------- helpers ----------------
    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, dp(12), 0, dp(4));
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText number(String hint, int value, LinearLayout parent) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(hint);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 2f));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(value));
        row.addView(e, new LinearLayout.LayoutParams(0, -2, 1f));
        parent.addView(row);
        return e;
    }

    private int num(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch (Exception ex) { return def; }
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
