package com.tri.wwmcode;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.List;

public class CodeService extends AccessibilityService {

    public static CodeService instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private Store store;

    // Bảng nổi
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView panelStatus;

    // Chạy
    private boolean running = false;
    private List<String> queue;
    private int idx, total, typeRetry;
    private boolean singleMode;

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        store = new Store(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { stop("Bị gián đoạn"); }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stop(null);
        hidePanel();
        instance = null;
        return super.onUnbind(intent);
    }

    /** Nhấn GIẢM ÂM LƯỢNG để dừng khẩn cấp. */
    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (running && e.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) stop("Đã dừng (nút âm lượng)");
            return true;
        }
        return false;
    }

    // =============== Bảng điều khiển nổi ===============
    private WindowManager.LayoutParams overlayLp(int w, int hgt, int extraFlags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, hgt,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | extraFlags,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    public void showPanel() {
        if (panel != null) return;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xDD1E2A30);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), 0xFF4FC3C7);
        panel.setBackground(bg);
        panel.setPadding(dp(6), dp(4), dp(6), dp(4));

        panelStatus = new TextView(this);
        panelStatus.setTextColor(Color.WHITE);
        panelStatus.setTextSize(12);
        panelStatus.setPadding(dp(6), 0, dp(6), 0);
        panelStatus.setText("⠿ " + store.pending().size() + " code");
        panel.addView(panelStatus);

        panel.addView(smallBtn("📍", v -> startCalibration()));
        panel.addView(smallBtn("1", v -> start(true)));
        panel.addView(smallBtn("▶", v -> start(false)));
        panel.addView(smallBtn("■", v -> stop("Đã dừng")));
        panel.addView(smallBtn("✕", v -> { stop(null); hidePanel(); }));

        panelLp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        panelLp.x = dp(20);
        panelLp.y = dp(20);

        // Kéo bảng bằng phần chữ trạng thái
        panelStatus.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = panelLp.x; oy = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = ox + (int) (e.getRawX() - sx);
                        panelLp.y = oy + (int) (e.getRawY() - sy);
                        wm.updateViewLayout(panel, panelLp);
                        return true;
                }
                return false;
            }
        });
        wm.addView(panel, panelLp);
    }

    private void hidePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) { }
            panel = null;
        }
    }

    private Button smallBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(2);
        b.setLayoutParams(lp);
        return b;
    }

    private void setStatus(String s) {
        if (panelStatus != null) panelStatus.setText("⠿ " + s);
    }

    // =============== Cài vị trí chạm ===============
    private static final String[] CAL_STEPS = {
            "Chạm vào Ô NHẬP CODE",
            "Chạm vào NÚT XÁC NHẬN (mũi tên cạnh ô nhập)",
            "Chạm vào VÙNG TRỐNG BÊN TRONG khung nhập code\n(dùng để đóng popup 'Nhận được')"
    };

    private void startCalibration() {
        if (running) return;
        final PointF[] pts = new PointF[3];
        final int[] step = {0};
        final MarkerView marker = new MarkerView(this);
        final TextView tip = new TextView(this);
        tip.setTextColor(Color.WHITE);
        tip.setTextSize(16);
        tip.setGravity(Gravity.CENTER);
        tip.setBackgroundColor(0xAA000000);
        tip.setPadding(dp(12), dp(8), dp(12), dp(8));
        tip.setText("1/3 • " + CAL_STEPS[0] + "\n(chạm 2 ngón để huỷ)");

        final FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(0x33000000);
        layer.addView(marker, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        tlp.bottomMargin = dp(24);
        layer.addView(tip, tlp);

        WindowManager.LayoutParams lp = overlayLp(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, 0);

        layer.setOnTouchListener((v, e) -> {
            if (e.getPointerCount() > 1) {
                try { wm.removeView(layer); } catch (Exception ignored) { }
                toast("Đã huỷ cài vị trí");
                return true;
            }
            if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
            pts[step[0]] = new PointF(e.getRawX(), e.getRawY());
            int[] loc = new int[2];
            layer.getLocationOnScreen(loc);
            marker.add(e.getRawX() - loc[0], e.getRawY() - loc[1], step[0] + 1);
            step[0]++;
            if (step[0] < 3) {
                tip.setText((step[0] + 1) + "/3 • " + CAL_STEPS[step[0]]);
            } else {
                store.savePoints(pts);
                tip.setText("Đã lưu 3 vị trí ✓");
                h.postDelayed(() -> {
                    try { wm.removeView(layer); } catch (Exception ignored) { }
                }, 1200);
            }
            return true;
        });
        wm.addView(layer, lp);
    }

    /** Vẽ số 1-2-3 tại các điểm đã chạm để kiểm tra. */
    private static class MarkerView extends View {
        private final java.util.ArrayList<float[]> pts = new java.util.ArrayList<>();
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        MarkerView(Context c) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            ring.setColor(0xFFFF5252);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3 * d);
            txt.setColor(Color.WHITE);
            txt.setTextSize(16 * d);
            txt.setFakeBoldText(true);
        }
        void add(float x, float y, int n) { pts.add(new float[]{x, y, n}); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float d = getResources().getDisplayMetrics().density;
            for (float[] p : pts) {
                c.drawCircle(p[0], p[1], 18 * d, ring);
                c.drawText(String.valueOf((int) p[2]), p[0] + 22 * d, p[1] - 10 * d, txt);
            }
        }
    }

    // =============== Chạy tự động ===============
    private void start(boolean single) {
        if (running) return;
        if (!store.calibrated()) { toast("Bấm 📍 để cài vị trí trước"); return; }
        queue = store.pending();
        if (queue.isEmpty()) { toast("Không còn code chưa nhập"); return; }
        if (panelCovers()) {
            toast("Bảng nổi đang che điểm chạm – kéo nó ra chỗ khác");
            return;
        }
        singleMode = single;
        total = single ? 1 : queue.size();
        idx = 0;
        running = true;
        stepTapInput();
    }

    private void stop(String msg) {
        boolean was = running;
        running = false;
        h.removeCallbacksAndMessages(null);
        if (msg != null && was) {
            toast(msg);
            setStatus(msg + " • còn " + store.pending().size());
        }
    }

    private void stepTapInput() {
        if (!running) return;
        if (idx >= total) {
            running = false;
            String m = singleMode ? "Thử xong 1 code – kiểm tra trong game" : "Hoàn tất " + total + " code ✓";
            setStatus(m);
            toast(m + ". Vào Hộp thư để nhận quà.");
            return;
        }
        typeRetry = 0;
        setStatus("▶ " + (idx + 1) + "/" + total + " " + queue.get(idx));
        tap(store.point(0));
        h.postDelayed(this::stepType, store.tapDelay());
    }

    private void stepType() {
        if (!running) return;
        String code = queue.get(idx);
        AccessibilityNodeInfo field = findEditable();
        boolean ok = field != null && typeInto(field, code);
        if (!ok) {
            if (typeRetry++ < 2) {           // thử chạm lại ô nhập
                tap(store.point(0));
                h.postDelayed(this::stepType, store.tapDelay() + 500);
            } else {
                stop("Không tìm thấy ô nhập chữ – thử tăng thời gian chờ");
            }
            return;
        }
        int wait = 400;
        if (store.imeEnter()) {
            h.postDelayed(() -> closeKeyboard(field), 300);
            wait = 900;
        }
        h.postDelayed(this::stepConfirm, wait);
    }

    private void stepConfirm() {
        if (!running) return;
        tap(store.point(1));
        h.postDelayed(() -> stepClose(store.closeTaps()), store.resultDelay());
    }

    private void stepClose(int left) {
        if (!running) return;
        if (left > 0) {
            tap(store.point(2));
            h.postDelayed(() -> stepClose(left - 1), 500);
            return;
        }
        store.markDone(queue.get(idx));
        idx++;
        h.postDelayed(this::stepTapInput, store.closeDelay());
    }

    // =============== Thao tác ===============
    private void tap(PointF p) {
        Path path = new Path();
        path.moveTo(p.x, p.y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 60))
                .build();
        dispatchGesture(g, null, null);
    }

    /** Tìm ô nhập chữ: ưu tiên ô đang focus, sau đó quét mọi cửa sổ. */
    private AccessibilityNodeInfo findEditable() {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f != null && f.isEditable()) return f;
        List<AccessibilityWindowInfo> wins = getWindows();
        AccessibilityNodeInfo any = null;
        for (AccessibilityWindowInfo w : wins) {
            AccessibilityNodeInfo r = w.getRoot();
            if (r == null || getPackageName().contentEquals(r.getPackageName() == null ? "" : r.getPackageName()))
                continue;
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
            q.add(r);
            while (!q.isEmpty()) {
                AccessibilityNodeInfo n = q.poll();
                if (n.isEditable()) {
                    if (n.isFocused()) return n;
                    if (any == null) any = n;
                }
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.add(c);
                }
            }
        }
        if (any == null) {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) {
                AccessibilityNodeInfo ff = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (ff != null && ff.isEditable()) return ff;
            }
        }
        return any;
    }

    private boolean typeInto(AccessibilityNodeInfo n, String code) {
        Bundle a = new Bundle();
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code);
        if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)) return true;
        // Dự phòng: dán qua clipboard
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("code", code));
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle sel = new Bundle();
        sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0);
        sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT,
                n.getText() == null ? 0 : n.getText().length());
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel);
        return n.performAction(AccessibilityNodeInfo.ACTION_PASTE);
    }

    private void closeKeyboard(AccessibilityNodeInfo field) {
        boolean done = false;
        if (Build.VERSION.SDK_INT >= 30 && field != null) {
            done = field.performAction(
                    AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }
        if (!done && keyboardVisible()) performGlobalAction(GLOBAL_ACTION_BACK);
    }

    private boolean keyboardVisible() {
        for (AccessibilityWindowInfo w : getWindows()) {
            if (w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) return true;
        }
        return false;
    }

    private boolean panelCovers() {
        if (panel == null) return false;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        for (int i = 0; i < 3; i++) {
            PointF p = store.point(i);
            if (p.x >= loc[0] && p.x <= loc[0] + panel.getWidth()
                    && p.y >= loc[1] && p.y <= loc[1] + panel.getHeight()) return true;
        }
        return false;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
